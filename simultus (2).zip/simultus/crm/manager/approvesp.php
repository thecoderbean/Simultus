<?php
	session_start();
	require_once '../config/connect.php';
	if (!isset($_SESSION['loggedin']) && $_SESSION['loggedin'] !== false) {
		header('location: ../login.php');
		exit;
	}
        $id = $_GET['id'];
        $sql ="UPDATE sp SET approve ='1' WHERE id='$id'";
		$res = mysqli_query($connection, $sql);
		if($res){
			$smsg = "Approved";
             header('location: sp.php');
		}else{
			$fmsg = "Approval failed";
             header('location: sp.php');
		}

?>

