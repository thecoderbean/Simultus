<?php
	session_start();
	require_once '../config/connect.php';
	if (!isset($_SESSION['loggedin']) && $_SESSION['loggedin'] !== false) {
		header('location: ../login.php');
		exit;
	}

	if(isset($_GET['id']) & !empty($_GET['id'])){
		$id = $_GET['id'];
		$sql = "SELECT username FROM crm WHERE id=$id";
		$res = mysqli_query($connection, $sql);
		$r = mysqli_fetch_assoc($res);
		if(!empty($r['username'])){
				$delsql = "DELETE FROM crm WHERE id=$id";
				if(mysqli_query($connection, $delsql)){
					// header("location:products.php");
				}
		}else{
			$delsql = "DELETE FROM crm WHERE id=$id";
				if(mysqli_query($connection, $delsql)){
					// header("location:products.php");
				}
		}

	}else{
		header('location: products.php');
	}   